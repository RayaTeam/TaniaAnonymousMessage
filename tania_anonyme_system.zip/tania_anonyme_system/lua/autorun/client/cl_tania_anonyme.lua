
-- Font 
surface.CreateFont( "tania_anonyme_font", { font = "Roboto", extended = false, size = 18, weight = 500, blursize = 0, scanlines = 0, antialias = true, })
surface.CreateFont( "tania_anonyme_textbox", { font = "Roboto", extended = false, size = 13, weight = 500, blursize = 0, scanlines = 0, antialias = true, })

-- Blur Background
local blur = Material("pp/blurscreen")
local function DrawBlur( p, a, d )
	local x, y = p:LocalToScreen( 0, 0 )

	surface.SetDrawColor( 255, 255, 255 )
	surface.SetMaterial( blur )

	for i = 1, d do
		blur:SetFloat( "$blur", (i / d ) * ( a ) )
		blur:Recompute()

		render.UpdateScreenEffectTexture()

		surface.DrawTexturedRect( x * -1, y * -1, ScrW(), ScrH() )
	end
end

net.Receive("tania_anonyme::OpenPanel", function()
	TaniaBase = vgui.Create("DFrame")
	TaniaBase:SetSize(500, 200)
	TaniaBase:Center()
	TaniaBase:SetTitle(TASConfig.DermaTitle)
	TaniaBase:SetDraggable(false)
	TaniaBase:SetBackgroundBlur(true)
	TaniaBase:ShowCloseButton(false)
	TaniaBase:MakePopup()

	TaniaBase.Paint = function(self, w, h)
		DrawBlur( self, 5, 15)
		draw.RoundedBox(0,0,0,w,h, TASConfig.DermaColor)
	end

	local TaniaClose = vgui.Create("DButton", TaniaBase)
    TaniaClose:SetPos(TaniaBase:GetWide() - 21, 5)
    TaniaClose:SetSize(16, 16)
    TaniaClose:SetText("")
    TaniaClose.DoClick = function()
        TaniaBase:Close()

    end
 
    local IconTaniaBtn = vgui.Create("DImage", TaniaBase)
    IconTaniaBtn:SetPos(TaniaBase:GetWide() - 21, 5)
    IconTaniaBtn:SetSize(16, 16)
    IconTaniaBtn:SetImage(TASConfig.DermaBtnIcon)

    local TaniaLabel = vgui.Create( "DLabel", TaniaBase)
	TaniaLabel:SetPos( 0, 2 )
	TaniaLabel:SetSize( 700, 45)
	TaniaLabel:SetText( "_____________________________________________________________________________________________________" )
	TaniaLabel:SetTextColor( Color( 255,255,255,255 ) )

	local TaniaLabel1 = vgui.Create( "DLabel", TaniaBase)
	TaniaLabel1:SetPos( 55, 50 )
	TaniaLabel1:SetSize( 700, 45)
	TaniaLabel1:SetText( TASConfig.BuyerInfoMsg )
	TaniaLabel1:SetFont("tania_anonyme_font")
	TaniaLabel1:SetTextColor( TASConfig.BuyerInfoColor )

	local TaniaLabel2 = vgui.Create( "DLabel", TaniaBase)
	TaniaLabel2:SetPos( 55, 80 )
	TaniaLabel2:SetSize( 700, 45)
	TaniaLabel2:SetText( TASConfig.BuyerInfoMsg2 )
	TaniaLabel2:SetFont("tania_anonyme_font")
	TaniaLabel2:SetTextColor( TASConfig.BuyerInfoColor )

	local TaniaTextBox = vgui.Create("DTextEntry", TaniaBase)
		TaniaTextBox:SetMultiline(true)
		TaniaTextBox:SetSize(300, 30)
		TaniaTextBox:SetPos(90, 130)
		TaniaTextBox.Paint = function( self, w, h ) 
			draw.RoundedBox( 0, 0, 0, w, h, Color( 255,255,255,255 ))
		end
		TaniaTextBox.OnEnter = function(ply)
			local msg = LocalPlayer():GetValue()
			if string.len(msg) > 3 then
				if Msg1textbox ~= msg then
					Msg2textbox = tostring(msg)
				end
        	end
		end
		
		local myTaniaTextBox = vgui.Create("DTextEntry", TaniaTextBox)
		myTaniaTextBox:SetSize(300, 30)
		myTaniaTextBox:Center()
		myTaniaTextBox:SetText(TASConfig.InfoPlayerTxt)
		myTaniaTextBox:SetFont("tania_anonyme_textbox")
		myTaniaTextBox:SetTextColor(Color(0,0,0,255))
		myTaniaTextBox.OnEnter = function(self)
			local col = team.GetColor(LocalPlayer():Team())
			local msg = self:GetValue()
			if string.len(msg) > 3 then
				local msg2 = { Color(255, 0, 0, 255), "[Tania Service Anonyme] ",
					Color(0,0,0,255), ": " .. tostring(msg) }
				net.Start("tania_anonyme::SendAllPlayers")
				net.WriteEntity(LocalPlayer())
				net.WriteTable(msg2)
				net.SendToServer()
			end
		end

		net.Receive("tania_anonyme::SendAllPlayers", function()
   		local message = net.ReadTable()
    	chat.AddText(unpack(message))
	end)

end)