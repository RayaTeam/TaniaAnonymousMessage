util.AddNetworkString("tania_anonyme::OpenPanel")
util.AddNetworkString("tania_anonyme::SendAllPlayers")

hook.Add("PlayerSay", "tania_anonyme", function(ply, text, teamchat)
	if text == "/anonyme" then 
		net.Start("tania_anonyme::OpenPanel")
		net.Send(ply)
		return ""
	end
end)

net.Receive("tania_anonyme::SendAllPlayers", function()
	local ply = net.ReadEntity()
    local message = net.ReadTable()
    local tags, pmsg = message[2], message[4]

    if DarkRP then
		if TASConfig.PriceMsgA > 0 then
			if not ply:canAfford(TASConfig.PriceMsgA) then
			DarkRP.notify(ply, 1, 8, tostring(TASConfig.NotifyNoPurchase))
			return
		end
			ply:addMoney(-TASConfig.PriceMsgA)
			DarkRP.notify(ply, 0, 8, tostring(TASConfig.NotifyPurchase))
			else DarkRP.notify(ply, 0, 8, tostring(TASConfig.NotifyPurchase)) end
		end

   		if not IsValid(ply) then return end
    		for _,v in ipairs(player.GetAll()) do
    			if not IsValid(v) then continue end
    			net.Start("tania_anonyme::SendAllPlayers")
				net.WriteTable(message)
				net.Send(v)
				if v:IsAdmin() then 
			v:PrintMessage(HUD_PRINTCONSOLE, tostring(tags) .. ply:Nick() .. " (" .. ply:SteamID() .. ")" .. tostring(pmsg)) -- admin in visible on console server
	 	end
	end
end)