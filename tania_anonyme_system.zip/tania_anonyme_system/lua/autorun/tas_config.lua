TASConfig                  = {}

-- Panel Frame Settings
TASConfig.DermaTitle       = "Tania Message Anonyme | Made by raya"
TASConfig.DermaBtnIcon     = "icon16/cross.png"
TASConfig.DermaColor       = Color(0,0,0,150)

TASConfig.BuyerInfoMsg     = "You will buy an anonymous message broadcast."
TASConfig.BuyerInfoMsg2    = "You would be covered by our AOP courier service."
TASConfig.InfoPlayerTxt    = "Create an anonymous message secured by Tania Service."
TASConfig.BuyerInfoColor   = Color(255,255,255,255)

-- Price Diffiuse Message Anonyme
TASConfig.PriceMsgA        = 1000

-- Notify Buy or not Buy Diffiuse Message
TASConfig.NotifyPurchase   = "You have to buy a message broadcast for "..TASConfig.PriceMsgA.." $"
TASConfig.NotifyNoPurchase = "You can not buy a message broadcast you need "..TASConfig.PriceMsgA.." $"